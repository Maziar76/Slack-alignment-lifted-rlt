# Slack Alignment and Lifted-RLT Exactness Experiments

Reproducibility materials for the numerical experiments accompanying the manuscript on slack alignment and exactness of equality-constrained box-QP relaxations.

## Contents

```text
src/
  unified_experiments.py       Main 300-instance experiment and report generator
  constructed_sharpness.py    Constructed pairwise-equality sharpness family
  coupled_experiment.py       Dense coupled reduced-Hessian experiment
results/
  main/                       Main experiment records, metadata, numerical summary, and LaTeX tables
  constructed/                CSV outputs and solver diagnostics for the constructed family
  coupled/                     CSV outputs and solver diagnostics for the coupled family
requirements.txt
```

The original exploratory notebook is intentionally not included. It contains intermediate attempts, superseded cells, and repeated installation/diagnostic steps. The three scripts above are the curated executable sources for the reported experiments.

## Environment

The reported run used Python 3.13.18, NumPy 2.4.6, SciPy 1.15.3, CVXPY 1.9.3, Clarabel 0.11.1, and SCS 3.3.2. Install the listed packages with:

```bash
python -m pip install -r requirements.txt
```

## Reproduce the main experiment

From the repository root:

```bash
python src/unified_experiments.py all --out results/reproduced --jobs 1
```

This runs the default experiment over dimensions 10, 20, and 50, ranks 1 and 5, and 50 instances per dimension/rank pair. It writes per-instance records, metadata, summary statistics, and LaTeX tables under `results/reproduced/`.

A small smoke test is:

```bash
python src/unified_experiments.py all --out results/smoke --per 2 --ns 10
```

## Reproduce the constructed and coupled families

```bash
python src/constructed_sharpness.py
python src/coupled_experiment.py
```

These scripts write their CSV outputs to the current working directory. The corresponding outputs from the reported runs are archived under `results/constructed/` and `results/coupled/`.

## Interpreting numerical diagnostics

The scripts report solver status and primal/dual residual information. In particular, the SCS dual objectives in the constructed and coupled experiments are numerical diagnostics; they have not been independently verified as formal dual-feasibility certificates. Do not interpret those values as rigorous certified lower bounds. The coupled experiment's reported feasible primal candidates and exact QP values should be interpreted according to the distinctions made in the manuscript between candidate-based gap witnesses and exact relaxation optima.

The archived `results/main/meta.json` records the settings and package versions for the main 300-instance run. `results/main/numbers.txt` and the LaTeX tables are the generated summaries associated with that archived run.

## Notes

- The main experiment is designed to regenerate its synthetic instances from its code and fixed random seeds; the archived JSONL file preserves the reported per-instance records.
- The constructed and coupled experiment scripts use fixed seeds and settings defined near the top of each script.
- Numerical results can vary slightly across operating systems, BLAS implementations, and solver builds.
