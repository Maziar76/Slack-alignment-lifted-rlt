#!/usr/bin/env python3
"""
unified_experiments.py
======================
ONE run that produces every number in Section "Numerical Experiments".

All four relaxations (Classical, Lifted, Classical-RLT, Lifted-RLT) are solved
on the SAME 300 instances (n in {10,20,50}, rank(N) in {1,5}, 50 each), with the
SAME solver (CLARABEL with a tighter retry, then SCS as a final fallback). All downstream solution analyses are gated by an independent primal-feasibility audit;
solver optimality is reported separately and is not inferred from feasibility. From each
Lifted-RLT / Classical-RLT solution the script also computes, on that same
solution: the localized condition (F, lambda_F, cert), the gap bound, the
fractional-threshold sweep, negative-curvature rounding, the cardinality
condition, and (n=10, first 5 instances per rank) the global optimum by face
enumeration.

Usage
-----
    pip install numpy scipy cvxpy clarabel scs
    python unified_experiments.py all    --out results --jobs 4
    # or in two steps:
    python unified_experiments.py run    --out results --jobs 4
    python unified_experiments.py report --out results

The run is resumable: instances already in results/instances.jsonl are skipped.
Quick smoke test:  python unified_experiments.py all --out test --per 2 --ns 10

Outputs (in --out)
    instances.jsonl        raw per-instance record
    meta.json              library versions, settings
    tables/*.tex           tab:rho, tab:models, tab:local, tab:local2,
                           tab:sweep, tab:gap, tab:round, tab:global
    numbers.txt            every statistic quoted in the prose, by paragraph
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import sys, json, time, argparse, itertools, platform, shutil
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from scipy.linalg import null_space, eigh, eigvalsh

# --------------------------------------------------------------------------
# settings (match the paper)
# --------------------------------------------------------------------------
DELTAS = [1e-7, 1e-6, 1e-5, 1e-4]       # fractional thresholds
DELTA_MAIN = 1e-6
EPS_RHO = 1e-8                          # rho_L <= 1+eps, rho_L < 1-eps
RANK_TOL = 1e-4                         # r_rank < 1e-4  => rank one
LAM_TOL = 1e-7                          # H_F^red PSD  <=>  lambda_F >= -1e-7
GAP_TOL = 1e-6                          # slack in the gap-bound check
ROUND_STOP = 1e-9                       # rounding stops if lambda_min >= -1e-9
CLARABEL_TOL = 1e-8                    # absolute/relative gap and feasibility tolerances
SCHEMA_VERSION = "solver-audited-support-screen-v4-2026-11-23"  # bump whenever record semantics change
SOLUTION_RESID_TOL = 1e-6              # independent post-solve feasibility screen
ROUND_FEAS_TOL = 1e-6                  # equality residual required after rounding
ROUND_BOX_TOL = SOLUTION_RESID_TOL     # use the same box scale as the primal audit
RETRY_CLARABEL_TOL = 1e-10
RETRY_SCS_EPS = 1e-8
DUAL_GAP_REL_TOL = 1e-7
DUAL_GAP_ABS_TOL = 1e-7
DUAL_RESID_TOL = 1e-6
SUPPORT_TOL = 1e-8
MODELS = {"C": (False, False), "L": (True, False),
          "CR": (False, True), "LR": (True, True)}   # name: (lifted, rlt)


def dk(d):
    return f"{d:.0e}"


# --------------------------------------------------------------------------
# instance generation   (seed = 100000 + 10000 n + j, as in the paper)
# --------------------------------------------------------------------------
def make_instance(n, r, j):
    seed = 100000 + 10000 * n + j
    rng = np.random.default_rng(seed)
    m = n // 2
    Qa, _ = np.linalg.qr(rng.standard_normal((n, m)))
    A = Qa.T                                         # m x n, orthonormal rows
    xtrue = rng.uniform(0.1, 0.9, n)
    b = A @ xtrue
    Q, _ = np.linalg.qr(rng.standard_normal((n, n)))
    lam = rng.uniform(0.1, 1.0, n)
    M = (Q * lam) @ Q.T
    theta = rng.uniform(0.1, 2.0, r)
    V, _ = np.linalg.qr(rng.standard_normal((n, r)))
    N = (V * theta) @ V.T
    H = M - N
    c = rng.standard_normal(n)
    c /= np.linalg.norm(c)
    N0 = null_space(A)
    Mr, Nr = N0.T @ M @ N0, N0.T @ N @ N0
    rhoC = eigh(N, M, eigvals_only=True)[-1]
    rhoL = eigh(Nr, Mr, eigvals_only=True)[-1]
    return dict(n=n, r=r, j=j, m=m, seed=seed, A=A, b=b, M=M, N=N, H=H, c=c,
                V=V, theta=theta, lamM_min=lam.min(), lamN_max=theta.max(),
                N0=N0, rhoC=rhoC, rhoL=rhoL)


def q(inst, x):
    return float(x @ inst["H"] @ x + inst["c"] @ x)


# --------------------------------------------------------------------------
# SDP solve (CVXPY + CLARABEL)
# --------------------------------------------------------------------------
def accuracy_diagnostics(inst, Zv, lifted, rlt):
    """Direct measures of how well the returned Z satisfies the constraints."""
    n, A, b = inst["n"], inst["A"], inst["b"]
    x, X = Zv[1:, 0], Zv[1:, 1:]
    d = dict(lin=float(np.abs(A @ x - b).max()),
             box=float(max(0.0, -x.min(), x.max() - 1.0)),
             psd=float(max(0.0, -np.linalg.eigvalsh(Zv)[0])))
    if lifted:
        d["lift"] = float(np.abs(A @ X - np.outer(b, x)).max())
    if rlt:
        ri, ci = np.triu_indices(n)
        Xu, xi, xj = X[ri, ci], x[ri], x[ci]
        d["rlt"] = float(max(0.0, (-Xu).max(), (Xu - xi).max(), (Xu - xj).max(),
                             (xi + xj - 1 - Xu).max()))
    return d


def _stats_mapping(obj):
    """Best-effort conversion of solver-specific stats to a plain mapping."""
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    out = {}
    for key in ("pobj", "dobj", "gap", "res_pri", "res_dual", "iterations",
                "solve_time", "status", "cost_primal", "cost_dual",
                "r_prim", "r_dual", "ktratio", "obj_val", "obj_val_dual",
                "gap_abs", "gap_rel"):
        try:
            val = getattr(obj, key)
            if val is not None and np.isscalar(val):
                out[key] = float(val) if isinstance(val, (int, float, np.number)) else str(val)
        except Exception:
            pass
    return out


def _solver_diagnostics(prob):
    """Extract objective/gap/residual information without assuming a solver schema."""
    ss = getattr(prob, "solver_stats", None)
    extra = _stats_mapping(getattr(ss, "extra_stats", None))
    info = extra.get("info") if isinstance(extra.get("info"), dict) else {}
    merged = dict(extra)
    merged.update({k: v for k, v in info.items() if k not in merged})
    def first(*names):
        for name in names:
            val = merged.get(name)
            try:
                val = float(val)
                if np.isfinite(val):
                    return val
            except (TypeError, ValueError):
                continue
        return None
    pobj = first("pobj", "cost_primal", "primal_obj", "obj_val")
    dobj = first("dobj", "cost_dual", "dual_obj", "obj_val_dual")
    gap = first("gap", "gap_abs", "rel_gap", "gap_rel")
    if gap is None and pobj is not None and dobj is not None:
        gap = abs(pobj - dobj)
    return dict(primal_objective=pobj, dual_objective=dobj, reported_gap=gap,
                primal_residual=first("res_pri", "r_prim", "res_primal"),
                dual_residual=first("res_dual", "r_dual"),
                iterations=getattr(ss, "num_iters", None),
                solve_time=getattr(ss, "solve_time", None),
                raw_stats={k: v for k, v in merged.items()
                           if isinstance(v, (str, int, float, bool)) or v is None})


def solve_sdp(inst, lifted, rlt):
    """Solve, retry inaccurate candidates, and independently audit primal feasibility.

    `primal_feasible` is a direct residual screen, not an optimality certificate.
    `solver_certified` is deliberately stricter: the solver must report `optimal`
    and expose finite primal/dual objectives plus acceptable gap and dual residual.
    Missing solver diagnostics are retained as missing, never inferred.
    """
    import cvxpy as cp
    from scipy.linalg import null_space as _ns
    n, A, b, H, c = inst["n"], inst["A"], inst["b"], inst["H"], inst["c"]
    if lifted:
        P = _ns(np.hstack([-b.reshape(-1, 1), A]))
        W = cp.Variable((P.shape[1], P.shape[1]), PSD=True)
        Zx = cp.Constant(P) @ W @ cp.Constant(P.T)
        cons = [Zx[0, 0] == 1]
    else:
        Zx = cp.Variable((n + 1, n + 1), PSD=True)
        cons = [Zx[0, 0] == 1,
                cp.Constant(A) @ Zx[1:, 0:1] == cp.Constant(b.reshape(-1, 1))]
    x, X = Zx[1:, 0], Zx[1:, 1:]
    cons += [x >= 0, x <= 1]
    if rlt:
        ri, ci = np.triu_indices(n)
        Xu, xi, xj = X[ri, ci], x[ri], x[ci]
        cons += [Xu >= 0, Xu <= xi, Xu <= xj, Xu >= xi + xj - 1]
    prob = cp.Problem(cp.Minimize(cp.sum(cp.multiply(cp.Constant(H), X))
                                  + cp.Constant(c) @ x), cons)

    attempts, candidates = [], []
    plan = [("CLARABEL", dict(tol_gap_abs=CLARABEL_TOL, tol_gap_rel=CLARABEL_TOL,
                               tol_feas=CLARABEL_TOL, max_iter=500)),
            ("CLARABEL", dict(tol_gap_abs=RETRY_CLARABEL_TOL,
                               tol_gap_rel=RETRY_CLARABEL_TOL,
                               tol_feas=RETRY_CLARABEL_TOL, max_iter=1000)),
            ("SCS", dict(eps=RETRY_SCS_EPS, max_iters=300000))]
    t0 = time.time()
    for solver_name, opts in plan:
        try:
            solver_const = cp.CLARABEL if solver_name == "CLARABEL" else cp.SCS
            prob.solve(solver=solver_const, **opts)
            status = str(prob.status)
            diag = _solver_diagnostics(prob)
            attempt = dict(solver=solver_name, status=status, diagnostics=diag, error=None)
            if status.startswith("optimal") and Zx.value is not None:
                Zv = np.asarray(Zx.value, dtype=float)
                Zv = (Zv + Zv.T) / 2
                primal_diag = accuracy_diagnostics(inst, Zv, lifted, rlt)
                max_resid = max(primal_diag.values()) if primal_diag else 0.0
                feasible = bool(np.isfinite(max_resid) and max_resid <= SOLUTION_RESID_TOL)
                attempt.update(primal_feasible=feasible, primal_diag=primal_diag,
                               max_primal_resid=float(max_resid))
                if feasible:
                    gap = diag.get("reported_gap")
                    dual_res = diag.get("dual_residual")
                    dual_obj = diag.get("dual_objective")
                    primal_obj = diag.get("primal_objective")
                    cert = bool(status == "optimal" and gap is not None
                                and dual_res is not None and dual_obj is not None
                                and primal_obj is not None
                                and gap <= DUAL_GAP_ABS_TOL + DUAL_GAP_REL_TOL * max(1.0, abs(primal_obj))
                                and dual_res <= DUAL_RESID_TOL)
                    candidates.append(dict(status=status, solver=solver_name, x=Zv[1:, 0].copy(),
                                           X=Zv[1:, 1:].copy(), diag=primal_diag,
                                           max_primal_resid=float(max_resid), primal_feasible=True,
                                           solver_certified=cert, solver_diag=diag, attempt_index=len(attempts)))
            attempts.append(attempt)
            # A clean solver optimal status plus feasible primal point and
            # exposed numerical primal/dual diagnostics is the only early exit.
            if candidates and candidates[-1]["solver_certified"]:
                break
        except Exception as e:
            attempts.append(dict(solver=solver_name, status="solver_error", diagnostics={},
                                 error=f"{type(e).__name__}: {e}"[:240]))

    if candidates:
        # Prefer a candidate with a reported gap; then the smallest gap, then
        # the smallest independently computed primal residual. Never promote
        # an uncertified candidate to certified status.
        def score(c):
            gap = c["solver_diag"].get("reported_gap")
            return (0 if c["solver_certified"] else 1,
                    0 if gap is not None else 1,
                    gap if gap is not None else np.inf, c["max_primal_resid"])
        best = min(candidates, key=score)
        res = dict(status=best["status"], solver=best["solver"],
                   time=time.time()-t0, bounded=True, primal_feasible=True,
                   solver_certified=best["solver_certified"], unbounded=False,
                   x=best["x"], X=best["X"], diag=best["diag"],
                   max_primal_resid=best["max_primal_resid"],
                   solver_diag=best["solver_diag"], attempts=attempts,
                   err=next((a["error"] for a in attempts if a.get("error")), None))
        return res

    last = attempts[-1] if attempts else {}
    status = last.get("status", "solver_error")
    return dict(status=status, solver=last.get("solver", "none"), time=time.time()-t0,
                bounded=False, primal_feasible=False, solver_certified=False,
                unbounded=str(status).startswith("unbounded"), err=last.get("error"),
                diag=last.get("primal_diag"), solver_diag=last.get("diagnostics", {}),
                attempts=attempts)


# --------------------------------------------------------------------------
# analysis of a computed solution
# --------------------------------------------------------------------------
def rank_stat(x, X):
    return float(np.linalg.norm(X - np.outer(x, x), "fro")
                 / max(1.0, np.linalg.norm(X, "fro")))


def face(inst, x, delta, lifted):
    """F, basis Z_F (orthonormal) of ker(A_F) [lifted] or R^|F| [classical]."""
    n, A = inst["n"], inst["A"]
    dist = np.minimum(x, 1 - x)
    F = np.where(dist > delta)[0]
    if len(F) == 0:
        return F, np.zeros((0, 0))
    Z = null_space(A[:, F]) if lifted else np.eye(len(F))
    return F, Z


def lam_F(inst, F, Z):
    if len(F) == 0 or Z.shape[1] == 0:
        return None                                      # = +infinity
    return float(eigvalsh(Z.T @ inst["H"][np.ix_(F, F)] @ Z)[0])


def local_analysis(inst, x, X, lifted, delta, r_rank):
    H, c, n = inst["H"], inst["c"], inst["n"]
    F, Z = face(inst, x, delta, lifted)
    lam = lam_F(inst, F, Z)
    S = X - np.outer(x, x)
    S = (S + S.T) / 2
    inF = np.zeros(n, bool)
    inF[F] = True
    out = ~inF
    trS = float(np.trace(S))
    sumxx = float(np.sum(x[F] * (1 - x[F])))
    pos = 0.0 if lam is None else max(-lam, 0.0)
    qx = q(inst, x)
    v = float(np.sum(H * X) + c @ x)
    hs = float(np.sum(H * S))
    hs_FF = float(np.sum(H[np.ix_(F, F)] * S[np.ix_(F, F)])) if len(F) else 0.0
    leak = 0.0
    if out.any():
        leak = float(max(np.abs(S[out, :]).max(), np.abs(S[:, out]).max()))
    dist = np.minimum(x, 1 - x)
    kdim = int(Z.shape[1]) if len(F) else 0
    cert = (len(F) == 0) or (kdim == 0) or (lam is not None and lam >= -LAM_TOL)
    # The localized gap bound needs slack supported on F x F.  Coordinates
    # outside F must be numerically at a box bound, and their slack rows/cols
    # must be negligible; otherwise the theorem's support premise is not met.
    out_dist = float(np.max(dist[out])) if out.any() else 0.0
    support_resid = max(leak, out_dist)
    support_ok = bool(support_resid <= SUPPORT_TOL)
    gap_value = qx - v
    gap_rhs = pos * trS
    gap_holds = (bool(gap_value <= gap_rhs + GAP_TOL) if support_ok else None)
    rec = dict(nF=int(len(F)), kdim=kdim, lam=lam, cert=bool(cert),
               rank_one=bool(r_rank < RANK_TOL), r_rank=r_rank,
               trS=trS, sumxx=sumxx, diag_out=float(np.sum(np.diag(S)[out])),
               hs_out=hs - hs_FF, leak=leak,
               rankS=int(np.sum(eigvalsh(S) > 1e-6)),
               mindistF=float(dist[F].min()) if len(F) else None,
               n_near=int(np.sum((dist > 0) & (dist <= 1e-4))),
               gap=gap_value, bnd_tr=gap_rhs, bnd_sum=pos * sumxx,
               bnd_card=pos * len(F) / 4.0,
               support_ok=support_ok, support_resid=support_resid,
               out_dist=out_dist, holds=gap_holds,
               ident_err=abs(v - (qx + hs)))
    return rec


def round_solution(inst, x0, delta, v):
    """Negative-curvature rounding while preserving the equality constraints.

    The previous implementation snapped every near-bound coordinate after
    each step.  Such simultaneous snapping need not preserve A x=b.  Here we
    move to an endpoint along a null(A_F) direction and set only the single
    blocking coordinate to its active bound; no global snapping is applied.
    """
    A, b, H, n = inst["A"], inst["b"], inst["H"], inst["n"]
    x = np.asarray(x0, dtype=float).copy()
    steps = 0

    def endpoint(direction, forward):
        if forward:
            ratios = np.full(n, np.inf)
            pos, neg = direction > 0, direction < 0
            ratios[pos] = (1.0 - x[pos]) / direction[pos]
            ratios[neg] = x[neg] / (-direction[neg])
        else:
            ratios = np.full(n, np.inf)
            pos, neg = direction > 0, direction < 0
            ratios[pos] = x[pos] / direction[pos]
            ratios[neg] = (1.0 - x[neg]) / (-direction[neg])
        k = int(np.argmin(ratios))
        t = float(ratios[k])
        if not np.isfinite(t) or t < -ROUND_BOX_TOL:
            return x.copy()
        t = max(0.0, t)
        y = x + (t if forward else -t) * direction
        # Set only the blocking coordinate exactly to the corresponding bound.
        if forward:
            y[k] = 1.0 if direction[k] > 0 else 0.0
        else:
            y[k] = 0.0 if direction[k] > 0 else 1.0
        # Correct harmless floating-point excursions without snapping other
        # coordinates (which could violate the affine equations).
        return y

    while steps < n + 1:
        F = np.where(np.minimum(x, 1 - x) > delta)[0]
        if len(F) == 0:
            break
        K = null_space(A[:, F])
        if K.shape[1] == 0:
            break
        w, W = eigh(K.T @ H[np.ix_(F, F)] @ K)
        if w[0] >= -ROUND_STOP:
            break
        d = np.zeros(n)
        d[F] = K @ W[:, 0]
        yp = endpoint(d, True)
        ym = endpoint(d, False)
        # Select the better endpoint; both are generated along a feasible
        # nullspace direction, up to floating-point arithmetic.
        x = yp if q(inst, yp) <= q(inst, ym) else ym
        steps += 1

    qh, qs = q(inst, x), q(inst, x0)
    resid = float(np.linalg.norm(A @ x - b))
    box_violation = float(max(0.0, -x.min(), x.max() - 1.0))
    F, Z = face(inst, x, delta, True)
    return dict(steps=steps, resid=resid,
                lam_hat=lam_F(inst, F, Z), qhat=qh, gap_after=qh - v,
                box_ok=bool(box_violation <= ROUND_BOX_TOL),
                # v is a primal SDP objective, not a certified lower bound.
                # Therefore qhat-v is diagnostic only and is NOT a validity test.
                valid=bool(resid <= ROUND_FEAS_TOL and box_violation <= ROUND_BOX_TOL
                           and qh <= qs + 1e-7),
                candidate_sdp_value=float(v),
                objective_change=float(qh - qs))



def cardinality(inst, x, delta):
    F, Z = face(inst, x, delta, True)
    ellF = float(np.sum((inst["V"] ** 2).sum(1)[F])) if len(F) else 0.0
    bound = inst["lamN_max"] * ellF / inst["lamM_min"]
    if len(F) == 0 or Z.shape[1] == 0:
        rhoF = 0.0
    else:
        E = np.zeros((inst["n"], Z.shape[1]))
        E[F, :] = Z
        rhoF = float(eigh(E.T @ inst["N"] @ E, E.T @ inst["M"] @ E,
                          eigvals_only=True)[-1])
    return dict(bound=bound, rhoF=rhoF, violated=bool(rhoF > bound + 1e-9),
                holds=bool(bound < 1))


def global_opt(inst):
    """min of x'Hx+c'x over {Ax=b, 0<=x<=1} by enumerating the 3^n faces."""
    n, A, b, H, c = inst["n"], inst["A"], inst["b"], inst["H"], inst["c"]
    best, bx = np.inf, None
    for st in itertools.product((0, 1, 2), repeat=n):
        s = np.array(st)
        F, U = np.where(s == 2)[0], np.where(s == 1)[0]
        xf = np.zeros(n)
        xf[U] = 1.0
        rhs = b - A[:, U].sum(1)
        if len(F) == 0:
            if np.linalg.norm(A @ xf - b) < 1e-9 and q(inst, xf) < best:
                best, bx = q(inst, xf), xf
            continue
        AF = A[:, F]
        x0F = np.linalg.lstsq(AF, rhs, rcond=None)[0]
        if np.linalg.norm(AF @ x0F - rhs) > 1e-9:
            continue
        Z = null_space(AF)
        if Z.shape[1] == 0:
            xF = x0F
        else:
            Hr = Z.T @ H[np.ix_(F, F)] @ Z
            ew = eigvalsh(Hr)
            if ew[0] < -1e-10:
                # An indefinite face has no relative-interior local minimum;
                # its minimum over the compact face lies on a lower-dimensional
                # face, which is enumerated separately.
                continue
            xt = xf.copy()
            xt[F] = x0F
            g = 2 * H @ xt + c
            gr = Z.T @ g[F]
            # For a singular PSD reduced Hessian, stationarity is solvable only
            # if the reduced gradient is orthogonal to its nullspace.  Use the
            # least-squares solution and check the residual explicitly.
            z, *_ = np.linalg.lstsq(2 * Hr, -gr, rcond=1e-10)
            if np.linalg.norm(2 * Hr @ z + gr) > 1e-8 * max(1.0, np.linalg.norm(gr)):
                continue
            # If Hr is singular, the stationary set is z + ker(Hr).  The
            # minimum-norm representative need not lie in the box even when
            # another representative does, so solve a small LP for a feasible
            # nullspace displacement rather than discarding this face.
            U = null_space(Hr)
            xbase = x0F + Z @ z
            if U.shape[1]:
                from scipy.optimize import linprog
                D = Z @ U
                lp = linprog(np.zeros(U.shape[1]),
                             A_ub=np.vstack([D, -D]),
                             b_ub=np.concatenate([1.0 - xbase, xbase]),
                             bounds=[(None, None)] * U.shape[1], method="highs")
                if not lp.success:
                    continue
                xF = xbase + D @ lp.x
            else:
                xF = xbase
        if xF.min() < -1e-9 or xF.max() > 1 + 1e-9:
            continue
        x = xf.copy()
        x[F] = np.clip(xF, 0, 1)
        val = q(inst, x)
        if val < best:
            best, bx = val, x
    if bx is None:
        raise RuntimeError("face enumeration found no feasible candidate; global optimum unavailable")
    return best


# --------------------------------------------------------------------------
# one instance, everything
# --------------------------------------------------------------------------
def run_instance(task):
    n, r, j, do_global, solver_fn = task
    inst = make_instance(n, r, j)
    out = dict(schema_version=SCHEMA_VERSION, n=n, r=r, j=j, seed=inst["seed"], rhoC=inst["rhoC"],
               rhoL=inst["rhoL"], lamH=float(eigvalsh(inst["H"])[0]),
               models={}, loc={}, gap_main=None, rounding=None, card=None,
               glob=None)
    for name, (lifted, rlt) in MODELS.items():
        sol = (solver_fn(inst, lifted, rlt) if solver_fn is not None
               else solve_sdp(inst, lifted, rlt))
        rec = {k: sol[k] for k in ("status", "solver", "time", "bounded", "primal_feasible", "unbounded")}
        rec["err"] = sol.get("err")
        rec["diag"] = sol.get("diag")
        rec["solver_certified"] = bool(sol.get("solver_certified", False))
        rec["solver_diag"] = sol.get("solver_diag", {})
        rec["attempts"] = sol.get("attempts", [])
        # A solver status is not a feasibility certificate.  All geometric,
        # rank, certificate, gap-bound, cardinality and rounding calculations
        # are restricted to independently audited primal-feasible candidates.
        rec["analysis_eligible"] = bool(sol.get("bounded") and sol.get("primal_feasible"))
        rec["optimality_eligible"] = bool(rec["analysis_eligible"] and rec["solver_certified"])
        if rec["analysis_eligible"]:
            x, X = sol["x"], sol["X"]
            rr = rank_stat(x, X)
            rec.update(r_rank=rr, rank_one=bool(rr < RANK_TOL),
                       value=float(np.sum(inst["H"] * X) + inst["c"] @ x))
            if rlt:
                out["loc"][name] = {dk(d): local_analysis(inst, x, X, lifted, d, rr)
                                    for d in DELTAS}
            if name == "LR":
                v = rec["value"]
                out["LR_qx"], out["LR_v"] = q(inst, x), v
                out["rounding"] = round_solution(inst, x, DELTA_MAIN, v)
                out["card"] = cardinality(inst, x, DELTA_MAIN)
        out["models"][name] = rec
    if do_global and "LR_v" in out:
        out["glob"] = dict(vqp=global_opt(inst), method="face-enumeration",
                            numerically_checked=True,
                            certification="floating-point enumeration; not an exact-arithmetic certificate")
    return out


# --------------------------------------------------------------------------
# driver: run
# --------------------------------------------------------------------------
def cmd_run(a, solver_fn=None):
    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, "instances.jsonl")
    done = set()
    if os.path.exists(path):
        # Never mix records produced by different solver/diagnostic pipelines.
        # Older files may have the same (n,r,j) keys but lack primal residuals,
        # or may have been solved with a different solver-selection rule.
        existing = []
        incompatible = False
        with open(path) as oldf:
            for line in oldf:
                if not line.strip():
                    continue
                d = json.loads(line)
                existing.append(d)
                if d.get("schema_version") != SCHEMA_VERSION:
                    incompatible = True
        if incompatible:
            legacy = path + ".legacy"
            suffix = 1
            while os.path.exists(legacy):
                legacy = path + f".legacy{suffix}"
                suffix += 1
            os.replace(path, legacy)
            print("Archived incompatible/legacy results as " + legacy, flush=True)
        else:
            # Keep only records with the complete current schema and reject
            # duplicate keys rather than silently letting report() double-count.
            for d in existing:
                key = (d["n"], d["r"], d["j"])
                if key in done:
                    raise RuntimeError(f"duplicate instance record in {path}: {key}")
                required = {"models", "loc", "rounding", "card", "schema_version"}
                if not required.issubset(d):
                    raise RuntimeError(f"incomplete current-schema record for {key}; archive/delete {path} before continuing")
                for nm in MODELS:
                    mr = d.get("models", {}).get(nm, {})
                    fields = {"primal_feasible", "diag", "analysis_eligible",
                              "solver_certified", "optimality_eligible", "solver_diag", "attempts"}
                    if not fields.issubset(mr):
                        raise RuntimeError(f"record {key}, model {nm}: incomplete solver-audit fields")
                done.add(key)
    ns = [int(s) for s in a.ns.split(",")]
    rs = [int(s) for s in a.ranks.split(",")]
    tasks = []
    for n in ns:
        for r in rs:
            for j in range(a.per):
                if (n, r, j) in done:
                    continue
                dg = (not a.no_global) and n <= a.global_maxn and j < a.global_k
                tasks.append((n, r, j, dg, solver_fn))
    meta = dict(schema_version=SCHEMA_VERSION, python=platform.python_version(), numpy=np.__version__,
                settings=dict(clarabel_tol_gap_abs=CLARABEL_TOL,
                             clarabel_tol_gap_rel=CLARABEL_TOL,
                             clarabel_tol_feas=CLARABEL_TOL,
                             solution_resid_tol=SOLUTION_RESID_TOL,
                             round_feas_tol=ROUND_FEAS_TOL,
                             retry_clarabel_tol=RETRY_CLARABEL_TOL,
                             retry_scs_eps=RETRY_SCS_EPS,
                             dual_gap_rel_tol=DUAL_GAP_REL_TOL,
                             dual_gap_abs_tol=DUAL_GAP_ABS_TOL,
                             dual_resid_tol=DUAL_RESID_TOL,
                             support_tol=SUPPORT_TOL,
                             facial_reduction_for_lifted=True, DELTAS=DELTAS, DELTA_MAIN=DELTA_MAIN, RANK_TOL=RANK_TOL,
                              LAM_TOL=LAM_TOL, GAP_TOL=GAP_TOL, per=a.per, ns=ns, ranks=rs))
    try:
        import scipy, cvxpy, clarabel, scs
        meta.update(scipy=scipy.__version__, cvxpy=cvxpy.__version__,
                    clarabel=getattr(clarabel, "__version__", "?"), scs=scs.__version__)
    except Exception as e:
        meta["versions_error"] = str(e)
    json.dump(meta, open(os.path.join(a.out, "meta.json"), "w"), indent=1)
    print(f"{len(tasks)} instances to run ({len(done)} already done)", flush=True)
    t0 = time.time()
    dump = lambda o: o.item() if hasattr(o, "item") else float(o)
    with open(path, "a") as f:
        if a.jobs <= 1 or solver_fn is not None:
            it = (run_instance(t) for t in tasks)
            for k, res in enumerate(it, 1):
                f.write(json.dumps(res, default=dump) + "\n"); f.flush()
                print(f"[{k}/{len(tasks)}] n={res['n']} r={res['r']} j={res['j']} "
                      f"({time.time()-t0:.0f}s)", flush=True)
        else:
            try:
                with ProcessPoolExecutor(max_workers=a.jobs) as ex:
                    futs = [ex.submit(run_instance, t) for t in tasks]
                    for k, fu in enumerate(as_completed(futs), 1):
                        res = fu.result()
                        f.write(json.dumps(res, default=dump) + "\n"); f.flush()
                        print(f"[{k}/{len(tasks)}] n={res['n']} r={res['r']} j={res['j']} "
                              f"({time.time()-t0:.0f}s)", flush=True)
            except Exception as e:                       # e.g. notebooks: fall back to serial
                print("parallel run failed (", repr(e), ") -> continuing serially", flush=True)
                f.flush()
                done2 = {(json.loads(l)["n"], json.loads(l)["r"], json.loads(l)["j"])
                         for l in open(path)}
                rest = [t for t in tasks if t[:3] not in done2]
                for k, t in enumerate(rest, 1):
                    res = run_instance(t)
                    f.write(json.dumps(res, default=dump) + "\n"); f.flush()
                    print(f"[serial {k}/{len(rest)}] n={res['n']} r={res['r']} j={res['j']} "
                          f"({time.time()-t0:.0f}s)", flush=True)


# --------------------------------------------------------------------------
# report
# --------------------------------------------------------------------------
def sci(v, d=2):
    if v is None:
        return "--"
    if v == 0:
        return "$0$"
    e = int(np.floor(np.log10(abs(v))))
    mnt = v / 10 ** e
    if round(abs(mnt), d) >= 10:
        mnt, e = mnt / 10, e + 1
    return f"${mnt:.{d}f}\\times10^{{{e}}}$"


def table(caption, label, colspec, header, rows, extra="\\small\\setlength{\\tabcolsep}{4pt}"):
    L = ["\\begin{table}[htbp]", f"\\centering{extra}", f"\\caption{{{caption}}}",
         f"\\label{{{label}}}", f"\\begin{{tabular}}{{{colspec}}}", "\\toprule",
         header + " \\\\", "\\midrule"]
    L += [" & ".join(str(c) for c in r) + " \\\\" for r in rows]
    L += ["\\bottomrule", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(L)


def lam_neg(l):
    return l is not None and l < -LAM_TOL


def cmd_report(a):
    path = os.path.join(a.out, "instances.jsonl")
    if not os.path.exists(path):
        raise FileNotFoundError(f"no instance results found at {path}; run the 'run' command first")
    recs = [json.loads(l) for l in open(path) if l.strip()]
    if not recs:
        raise RuntimeError(f"no instance records found in {path}; run the 'run' command first")
    bad = [d for d in recs if d.get("schema_version") != SCHEMA_VERSION]
    if bad:
        raise RuntimeError(
            f"{len(bad)} legacy/incompatible records found in {path}. "
            "Do not report mixed results: run the 'run' command to archive the old file and recompute."
        )
    keys_seen = set()
    for d in recs:
        key = (d["n"], d["r"], d["j"])
        if key in keys_seen:
            raise RuntimeError(f"duplicate instance record in {path}: {key}")
        keys_seen.add(key)
        for nm in MODELS:
            mr = d.get("models", {}).get(nm, {})
            if ("primal_feasible" not in mr or "diag" not in mr
                    or "analysis_eligible" not in mr or "solver_certified" not in mr
                    or "optimality_eligible" not in mr):
                raise RuntimeError(f"record {key}, model {nm}: missing current feasibility-gating fields")
    recs.sort(key=lambda d: (d["n"], d["r"], d["j"]))
    groups = {}
    for d in recs:
        groups.setdefault((d["n"], d["r"]), []).append(d)
    keys = sorted(groups)
    tdir = os.path.join(a.out, "tables")
    os.makedirs(tdir, exist_ok=True)
    mk = dk(DELTA_MAIN)
    NUM = []                                                # numbers.txt lines
    P = lambda s="": NUM.append(s)

    def LRl(d, k=mk):  return d["loc"].get("LR", {}).get(k)
    def CRl(d, k=mk):  return d["loc"].get("CR", {}).get(k)
    def mod(d, name):  return d["models"][name]
    def ro(d, name):
        mr = d["models"][name]
        return bool(mr.get("analysis_eligible", False) and mr.get("rank_one", False))
    def bd(d, name):   return bool(d["models"][name]["bounded"])
    ntot = len(recs)
    npg = {k: len(v) for k, v in groups.items()}
    nstr = "/".join(sorted({str(v) for v in npg.values()}))

    # ---------------- tab:rho
    rows = []
    for k in keys:
        g = groups[k]
        rows.append([k[0], k[1], len(g),
                     f"{np.mean([d['rhoC'] for d in g]):.4f}",
                     f"{np.mean([d['rhoL'] for d in g]):.4f}",
                     f"{np.mean([d['rhoL']/d['rhoC'] for d in g]):.4f}",
                     sum(d['rhoC'] < 1 - EPS_RHO for d in g),
                     sum(d['rhoL'] < 1 - EPS_RHO for d in g)])
    open(os.path.join(tdir, "tab_rho.tex"), "w").write(table(
        "Alignment constants for the classical and lifted slack cones "
        "(bars denote averages over the $N_{\\rm inst}$ instances).", "tab:rho", "rrrrrrrr",
        "$n$ & $\\operatorname{rank}(N)$ & $N_{\\rm inst}$ & $\\overline{\\rho}_C$ & "
        "$\\overline{\\rho}_L$ & $\\overline{\\rho_L/\\rho_C}$ & $\\rho_C<1$ & $\\rho_L<1$", rows))
    ratios = [np.mean([d['rhoL']/d['rhoC'] for d in groups[k]]) for k in keys]
    P("== Paragraph 'Alignment constants'")
    P(f"avg ratio rho_L/rho_C range: {min(ratios):.4f} .. {max(ratios):.4f}"
      f"  (reduction {100*(1-max(ratios)):.0f}--{100*(1-min(ratios)):.0f} %)")
    for k in keys:
        g = groups[k]
        P(f"  n={k[0]} r={k[1]}: rho_C<1: {sum(d['rhoC']<1-EPS_RHO for d in g)}, "
          f"rho_L<1: {sum(d['rhoL']<1-EPS_RHO for d in g)} of {len(g)}")
    nrhoL_lt = sum(d['rhoL'] < 1 - EPS_RHO for d in recs)
    P(f"total rho_L<1: {nrhoL_lt};  total rho_L>=1: {ntot-nrhoL_lt};  total N = {ntot}")

    # ---------------- tab:models
    rows = []
    for k in keys:
        g = groups[k]
        rows.append([k[0], k[1], len(g), sum(bd(d, "C") for d in g),
                     sum(bd(d, "L") for d in g), sum(bd(d, "CR") for d in g),
                     sum(ro(d, "L") for d in g), sum(ro(d, "CR") for d in g),
                     sum(ro(d, "LR") for d in g)])
    hdr = ("\\multirow{2}{*}{$n$} & \\multirow{2}{*}{$\\operatorname{rank}(N)$} & "
           "\\multirow{2}{*}{$N_{\\rm inst}$} & \\multicolumn{3}{c}{Bounded} & "
           "\\multicolumn{3}{c}{Rank-one ($r_{\\rm rank}<10^{-4}$)} \\\\\n"
           "\\cmidrule(lr){4-6} \\cmidrule(lr){7-9}\n & & & Classical & Lifted & "
           "Classical-RLT & Lifted & Classical-RLT & Lifted-RLT")
    open(os.path.join(tdir, "tab_models.tex"), "w").write(table(
        "Numerical boundedness and rank-one consistency (number of instances out of "
        "$N_{\\rm inst}$ classified as bounded, or satisfying $r_{\\rm rank}<10^{-4}$).",
        "tab:models", "lrrrrrrrr", hdr, rows, "\\small\\setlength{\\tabcolsep}{4pt}"))
    P(); P("== Paragraph 'Boundedness and rank-one consistency'")
    agreeC = sum(bd(d, "C") == (d['rhoC'] <= 1 + EPS_RHO) for d in recs)
    agreeL = sum(bd(d, "L") == (d['rhoL'] <= 1 + EPS_RHO) for d in recs)
    P(f"solver-status bounded == theory (diagnostic only): Classical {agreeC}/{ntot}, Lifted {agreeL}/{ntot}")
    P(f"Both RLT models bounded: CR {sum(bd(d,'CR') for d in recs)}/{ntot}, "
      f"LR {sum(bd(d,'LR') for d in recs)}/{ntot}")
    P("primal-feasible / analysis-eligible candidates (all direct residuals <= "
      f"{SOLUTION_RESID_TOL:.0e}):")
    for nm in MODELS:
        P(f"  {nm}: {sum(bool(mod(d,nm).get('primal_feasible',False)) for d in recs)}/{ntot}; "
          f"solver-certified optimal: {sum(bool(mod(d,nm).get('solver_certified',False)) for d in recs)}/{ntot}")
    lt = [d for d in recs if d['rhoL'] < 1 - EPS_RHO]
    P(f"instances with rho_L<1: {len(lt)}; Lifted rank-one among them: {sum(ro(d,'L') for d in lt)}")
    P(f"Lifted rank-one total: {sum(ro(d,'L') for d in recs)}")
    P("solver status counts by model:")
    cnt = {}
    for d in recs:
        for nm in MODELS:
            key = (nm, mod(d, nm)['status'], mod(d, nm)['solver'])
            cnt[key] = cnt.get(key, 0) + 1
    for key, v in sorted(cnt.items()):
        P(f"  model {key[0]:2s} status={key[1]:22s} solver={key[2]:8s} count={v}")

    P("distinct solver exception messages (CLARABEL errors that triggered the SCS fallback):")
    msgs = {}
    for d in recs:
        for nm in MODELS:
            e = mod(d, nm).get('err')
            if e:
                msgs[(nm, e[:110])] = msgs.get((nm, e[:110]), 0) + 1
    for (nm, e), v in sorted(msgs.items()):
        P(f"  model {nm}: {v} x {e}")
    if not msgs:
        P("  none")

    P(); P("== Solution accuracy: direct constraint residuals of the returned Z  (max / median over solves)")
    for nm in MODELS:
        Dg = [mod(d, nm)['diag'] for d in recs if mod(d, nm).get('diag')]
        if not Dg:
            continue
        ks = sorted({k for x in Dg for k in x})
        P(f"  {nm:2s} ({len(Dg)} solves): " + "; ".join(
            f"{k} {max(x[k] for x in Dg if k in x):.1e}/{np.median([x[k] for x in Dg if k in x]):.1e}"
            for k in ks))
    P("  (lin = |Ax-b|, lift = |AX-bx^T|, box = box violation, psd = -lambda_min(Z), rlt = worst RLT violation)")

    P(); P("== Per-row values (for Tables rho / models)")
    for k in keys:
        g = groups[k]
        P(f"  n={k[0]} r={k[1]}: mean rho_C {np.mean([d['rhoC'] for d in g]):.4f}, "
          f"mean rho_L {np.mean([d['rhoL'] for d in g]):.4f}, mean ratio "
          f"{np.mean([d['rhoL']/d['rhoC'] for d in g]):.4f} | bounded C/L/CR/LR = "
          f"{sum(bd(d,'C') for d in g)}/{sum(bd(d,'L') for d in g)}/{sum(bd(d,'CR') for d in g)}/{sum(bd(d,'LR') for d in g)}"
          f" | rank-one L/CR/LR = {sum(ro(d,'L') for d in g)}/{sum(ro(d,'CR') for d in g)}/{sum(ro(d,'LR') for d in g)}")
    P(f"Classical-RLT rank-one total: {sum(ro(d,'CR') for d in recs)}/{ntot}; "
      f"among rho_L<1: {sum(ro(d,'CR') for d in recs if d['rhoL']<1-EPS_RHO)}/"
      f"{sum(1 for d in recs if d['rhoL']<1-EPS_RHO)}")
    P("feasible, analysis-eligible solutions that are NOT rank one (identify these instances):")
    anyn = False
    for d in recs:
        for nm in ("L", "CR", "LR"):
            if mod(d, nm).get("analysis_eligible", False) and not ro(d, nm):
                m_ = mod(d, nm)
                x_ = (d['loc'].get(nm) or {}).get(mk)
                extra = (f", lam_F={x_['lam']}, tr(S)={x_['trS']:.2e}, |F|={x_['nF']}" if x_ else "")
                P(f"  n={d['n']} r={d['r']} j={d['j']} model={nm} status={m_['status']} solver={m_['solver']} "
                  f"r_rank={m_['r_rank']:.2e} rho_L={d['rhoL']:.3f}{extra}")
                anyn = True
    if not anyn:
        P("  none")

    # ---------------- paragraph 'Instances where certificate unavailable'
    ge = [d for d in recs if d['rhoL'] >= 1 - EPS_RHO]
    P(); P("== Paragraph 'Instances where the certificate is unavailable'")
    P(f"#instances rho_L>=1: {len(ge)}")
    c_cr, c_lr = sum(ro(d, 'CR') for d in ge), sum(ro(d, 'LR') for d in ge)
    P(f"Classical-RLT rank-one: {c_cr} ({100*c_cr/max(1,len(ge)):.2f} %); "
      f"Lifted-RLT rank-one: {c_lr} ({100*c_lr/max(1,len(ge)):.2f} %)")
    for k in keys:
        gg = [d for d in groups[k] if d['rhoL'] >= 1 - EPS_RHO]
        P(f"  n={k[0]} r={k[1]}: rho_L>=1 in {len(gg)}; CR rank-one {sum(ro(d,'CR') for d in gg)}, "
          f"LR rank-one {sum(ro(d,'LR') for d in gg)}")

    # ---------------- localized condition
    def lam_stats(g, k=mk):
        L = [LRl(d, k) for d in g if LRl(d, k)]
        cert = [x['cert'] for x in L]; rk = [x['rank_one'] for x in L]
        return L, cert, rk
    rows1, rows2 = [], []
    for k in keys:
        g = groups[k]; L, cert, rk = lam_stats(g)
        ncert = sum(cert)
        agree = sum(c == r_ for c, r_ in zip(cert, rk))
        crro = sum(ro(d, 'CR') for d in g)
        lrro = sum(rk)
        r_lt = sum(d['rhoL'] < 1 - EPS_RHO for d in g)
        mF = np.mean([x['nF'] for x in L])
        kerne = sum(1 for x in L if x['rank_one'] and x['kdim'] > 0)
        rows1.append([k[0], k[1], r_lt, crro, lrro, ncert, f"{mF:.1f} ({k[0]//2})", kerne])
        rows2.append([k[0], k[1], r_lt, lrro, ncert, agree,
                      sum(lam_neg(x['lam']) for x in L), f"{mF:.2f} ({k[0]//2})"])
    foot = "\\footnotesize\\setlength{\\tabcolsep}{3pt}"
    open(os.path.join(tdir, "tab_local.tex"), "w").write(table(
        f"Lifted-RLT and Classical-RLT on the common instance set ({nstr} instances per row, "
        f"$\\delta=10^{{-6}}$). ``Cert.'' counts instances where $\\ker(A_F)=\\{{0\\}}$ or "
        "$H_F^{\\rm red}\\succeq0$ at the computed Lifted-RLT solution. The last column counts "
        "rank-one solutions with $\\ker(A_F)\\ne\\{0\\}$.", "tab:local", "rrrrrrrr",
        "$n$ & $\\operatorname{rank}(N)$ & $\\rho_L<1$ & C-RLT rank-one & L-RLT rank-one & "
        "Cert. & mean $|F|$ ($m$) & rank-one, $\\ker(A_F)\\ne\\{0\\}$", rows1, foot))
    open(os.path.join(tdir, "tab_local2.tex"), "w").write(table(
        f"Lifted-RLT, {nstr} instances per row, $\\delta=10^{{-6}}$. ``Cert.'' counts instances "
        "with $\\ker(A_F)=\\{0\\}$ or $\\lambda_F\\ge-10^{-7}$. ``Agree'' counts instances where "
        "``Cert.'' and the rank-one test give the same answer. ``$\\lambda_F<0$'' counts "
        "instances with $\\lambda_F<-10^{-7}$.", "tab:local2", "rrrrrrrr",
        "$n$ & $\\operatorname{rank}(N)$ & $\\rho_L<1$ & Rank-one & Cert. & Agree & "
        "$\\lambda_F<0$ & mean $|F|$ ($m$)", rows2, "\\small\\setlength{\\tabcolsep}{4pt}"))

    P(); P("== Paragraphs 'Direct evaluation' / 'Localized condition' (delta=1e-6)")
    L = [LRl(d) for d in recs if LRl(d)]
    cert = [x['cert'] for x in L]; rk = [x['rank_one'] for x in L]
    a_ = sum((not c) and r_ for c, r_ in zip(cert, rk))
    b_ = sum(c and (not r_) for c, r_ in zip(cert, rk))
    P(f"Cert. holds in {sum(cert)}/{len(L)};  rank-one {sum(rk)}/{len(L)}")
    P(f"a = (not cert, rank one) = {a_};   b = (cert, not rank one) = {b_}   "
      f"=> sufficiency violations: {b_}")
    P(f"instances with rho_L<1: {nrhoL_lt}, rank-one among them (LR): "
      f"{sum(ro(d,'LR') for d in lt)}")
    P(f"instances with rho_L>=1: {len(ge)}; LR rank-one among them: {c_lr} "
      f"({100*c_lr/max(1,len(ge)):.1f} %)")
    P(f"rank-one LR solutions with ker(A_F)!=0: {sum(1 for x in L if x['rank_one'] and x['kdim']>0)} "
      f"of {sum(rk)} rank-one")
    cr = [CRl(d) for d in recs if CRl(d)]
    P(f"Classical-RLT: agreement cert vs rank-one {sum(x['cert']==x['rank_one'] for x in cr)}/{len(cr)}")
    P("per row (n, r): a / b / lambda_F<0 count / lambda_F<0 & rank-one / lambda_F<0 & NOT rank-one")
    for k in keys:
        Lg = [LRl(d) for d in groups[k] if LRl(d)]
        P(f"  n={k[0]} r={k[1]}: a={sum((not x['cert']) and x['rank_one'] for x in Lg)} "
          f"b={sum(x['cert'] and not x['rank_one'] for x in Lg)} "
          f"lam<0={sum(lam_neg(x['lam']) for x in Lg)} "
          f"lam<0&rank1={sum(lam_neg(x['lam']) and x['rank_one'] for x in Lg)} "
          f"lam<0&notrank1={sum(lam_neg(x['lam']) and not x['rank_one'] for x in Lg)}")
    P("per row, rho_L>=1 and r=5: LR rank-one / total")
    for k in keys:
        if k[1] != 5:
            continue
        gg = [d for d in groups[k] if d['rhoL'] >= 1 - EPS_RHO]
        P(f"  n={k[0]}: {sum(ro(d,'LR') for d in gg)}/{len(gg)}")
    P("Lemma (support/rank bound) at delta=1e-4: max slack leakage outside FxF, and rank-bound violations")
    for dd in ("1e-06", "1e-04"):
        Ld = [LRl(d, dd) for d in recs if LRl(d, dd)]
        P(f"  delta={dd}: max leak = {max(x['leak'] for x in Ld):.2e};  "
          f"rankS > |F|-rank(A_F) in {sum(x['rankS'] > x['kdim'] for x in Ld)} instances")

    # ---- necessity anomalies and trace comparison (resolves the open question)
    P(); P("== Paragraph 'Dependence on the threshold' (anomalies at delta=1e-6)")
    an = [(d, LRl(d)) for d in recs if LRl(d) and lam_neg(LRl(d)['lam']) and LRl(d)['rank_one']]
    P(f"#instances with lambda_F<0 and rank one: {len(an)}")
    if an:
        P("  min dist of fractional coord to bound: "
          f"{min(x['mindistF'] for _, x in an):.2e} .. {max(x['mindistF'] for _, x in an):.2e}")
        P(f"  #coords within 1e-4 of a bound (not on it): {min(x['n_near'] for _, x in an)} .. "
          f"{max(x['n_near'] for _, x in an)}")
        P(f"  lambda_F: {min(x['lam'] for _, x in an):.3f} .. {max(x['lam'] for _, x in an):.3f}")
        P(f"  tr(S): {min(x['trS'] for _, x in an):.2e} .. {max(x['trS'] for _, x in an):.2e}")
        P(f"  r_rank: {min(x['r_rank'] for _, x in an):.2e} .. {max(x['r_rank'] for _, x in an):.2e}")
    cs = [LRl(d)['trS'] for d in recs if LRl(d) and LRl(d)['cert'] and LRl(d)['rank_one']]
    if cs:
        P(f"tr(S) at CERTIFIED rank-one instances ({len(cs)}): median {np.median(cs):.2e}, "
          f"95th pct {np.percentile(cs,95):.2e}, max {max(cs):.2e}   <- compare with the line above")
    nr = [(d, LRl(d)) for d in recs if LRl(d) and not LRl(d)['rank_one']]
    P(f"non-rank-one LR solutions ({len(nr)}): tr(S) = " +
      (", ".join(f"{x['trS']:.2e}" for _, x in nr[:15]) if nr else "none"))

    # ---------------- sweep
    rows = []
    P(); P("== Table sweep (all instances)")
    for d_ in DELTAS:
        k = dk(d_)
        Ld = [LRl(d, k) for d in recs if LRl(d, k)]
        c_ = sum(x['cert'] for x in Ld); r_ = sum(x['rank_one'] for x in Ld)
        cnr = sum(x['cert'] and not x['rank_one'] for x in Ld)
        lr = sum(lam_neg(x['lam']) and x['rank_one'] for x in Ld)
        ln = sum(lam_neg(x['lam']) and not x['rank_one'] for x in Ld)
        assessed = [x for x in Ld if x.get('holds') is not None]
        gf = sum(x['holds'] is False for x in assessed)
        unassessed = len(Ld) - len(assessed)
        rows.append([f"$10^{{{int(round(np.log10(d_)))}}}$", c_, r_, cnr, lr, gf])
        P(f"  delta={k}: cert {c_}, rank-one {r_}, cert&notrank1 {cnr}, lam<0&rank1 {lr}, "
          f"lam<0&notrank1 {ln}, gap-bound failed {gf}/{len(assessed)} assessed, "
          f"unassessed (support screen) {unassessed}")
    open(os.path.join(tdir, "tab_sweep.tex"), "w").write(table(
        f"Effect of the fractional threshold $\\delta$ on the {ntot} Lifted-RLT solutions. "
        "``Cert.'' as in Table~\\ref{tab:local2}. The rank-one count does not depend on $\\delta$. "
        "``Gap bound fails'' counts instances violating the check of Proposition~\\ref{prop:gap}.",
        "tab:sweep", "rrrrrr",
        "$\\delta$ & Cert. & Rank-one & Cert., not rank one & $\\lambda_F<0$, rank one & Gap bound fails",
        rows))

    # ---------------- gap
    rows = []
    P(); P("== Paragraph 'Gap bound' (delta=1e-6)")
    for k in keys:
        Lg = [LRl(d) for d in groups[k] if LRl(d)]
        assessed = [x for x in Lg if x.get("holds") is not None]
        passed = sum(x["holds"] is True for x in assessed)
        failed = sum(x["holds"] is False for x in assessed)
        unassessed = len(Lg) - len(assessed)
        rows.append([k[0], k[1], f"{passed}/{len(assessed)}", unassessed,
                     sci(np.mean([x['gap'] for x in Lg])) if Lg else "--",
                     sci(np.mean([x['bnd_tr'] for x in Lg])) if Lg else "--",
                     sci(np.mean([x['bnd_sum'] for x in Lg])) if Lg else "--"])
        P(f"  n={k[0]} r={k[1]}: passed {passed}/{len(assessed)} assessed; "
          f"failed {failed}; unassessed {unassessed}; "
          f"mean gap {np.mean([x['gap'] for x in Lg]):.3e}; "
          f"mean tr-bound {np.mean([x['bnd_tr'] for x in Lg]):.3e}; "
          f"mean sum-bound {np.mean([x['bnd_sum'] for x in Lg]):.3e}" if Lg else
          f"  n={k[0]} r={k[1]}: no analysis-eligible Lifted-RLT solution")
    open(os.path.join(tdir, "tab_gap.tex"), "w").write(table(
        f"Gap-bound diagnostic on Lifted-RLT solutions, {nstr} instances per row, "
        r"$\delta=10^{-6}$. The test is assessed only when the numerical support screen "
        r"$\max\{\|S_{F^c,:}\|_\infty,\mathrm{dist}(x_{F^c},\{0,1\})\}"
        r"\leq\tau_{\rm supp}$ is satisfied; otherwise it is unassessed.",
        "tab:gap", "rrrrrrr",
        r"$n$ & $\operatorname{rank}(N)$ & Passed / assessed & Unassessed & mean gap & "
        r"$[-\lambda_F]_+\tr(S)$ & $[-\lambda_F]_+\sum_F x_i(1-x_i)$", rows))
    fails = [(d, LRl(d)) for d in recs if LRl(d) and LRl(d).get('holds') is False]
    unassessed_gap = [(d, LRl(d)) for d in recs if LRl(d) and LRl(d).get('holds') is None]
    P(f"gap-bound failures at delta=1e-6: {len(fails)} assessed failures; "
      f"{len(unassessed_gap)} unassessed by support screen")
    for d, x in fails[:40]:
        P(f"    n={d['n']} r={d['r']} j={d['j']}: gap={x['gap']:.2e}, rhs={x['bnd_tr']:.2e}, "
          f"lam_F={x['lam']}, support_resid={x['support_resid']:.2e}")
    if fails:
        P(f"  gap range {min(x['gap'] for _,x in fails):.2e} .. {max(x['gap'] for _,x in fails):.2e}; "
          f"max gap-minus-rhs {max(x['gap']-x['bnd_tr'] for _,x in fails):.2e}")
    P(f"max |identity error| (objective = q + <H,S>): {max(x['ident_err'] for x in L):.1e}" if L else
      "max |identity error|: no Lifted-RLT analysis-eligible solutions")

    # ---------------- rounding
    rows = []
    P(); P("== Paragraph 'Rounding'")
    allsteps = sum(d['rounding']['steps'] for d in recs if d['rounding'])
    P(f"total rounding steps: {allsteps};  valid: {sum(d['rounding']['valid'] for d in recs if d['rounding'])}"
      f"/{sum(1 for d in recs if d['rounding'])};  all in box: "
      f"{all(d['rounding']['box_ok'] for d in recs if d['rounding'])};  "
      f"max residual: {max(d['rounding']['resid'] for d in recs if d['rounding']):.2e}")
    allham = [d['rounding']['lam_hat'] for d in recs if d['rounding'] and d['rounding']['lam_hat'] is not None]
    P(f"min lambda_F(x_hat) over instances with nontrivial kernel: {min(allham):.4f}" if allham else "no nontrivial kernel")
    for k in keys:
        R = [d['rounding'] for d in groups[k] if d['rounding']]
        lh = [x['lam_hat'] for x in R if x['lam_hat'] is not None]
        before = np.mean([d['LR_qx'] - d['LR_v'] for d in groups[k] if d['rounding']])
        after = np.mean([x['gap_after'] for x in R])
        rows.append([k[0], k[1], sum(x['valid'] for x in R), f"{np.mean([x['steps'] for x in R]):.2f}",
                     sci(before), sci(after), sci(max(x['resid'] for x in R), 1),
                     f"{min(lh):.3f}" if lh else "--"])
        P(f"  n={k[0]} r={k[1]}: valid {sum(x['valid'] for x in R)}/{len(R)}, mean steps "
          f"{np.mean([x['steps'] for x in R]):.2f}, gap before {before:.3e}, after {after:.3e}"
          + (f", reduction factor {before/after:.1f}" if after > 0 and before > 0 else ""))
    open(os.path.join(tdir, "tab_round.tex"), "w").write(table(
        "Negative-curvature rounding (Proposition~\\ref{prop:rounding}) started at the Lifted-RLT "
        f"solution, {nstr} instances per row. ``Valid'' counts runs with "
        "$q(\\hat x)\\le q(x^\\star)+10^{-7}$ and $q(\\hat x)-v_{\\rm LR}\\ge-10^{-6}$. The gaps are "
        "$q(x^\\star)-v_{\\rm LR}$ and $q(\\hat x)-v_{\\rm LR}$, averaged over the row. The last two "
        "columns give the largest feasibility residual and the smallest $\\lambda_F$ at $\\hat x$ "
        "over the row.", "tab:round", "rrrrrrrr",
        "$n$ & $\\operatorname{rank}(N)$ & Valid & mean steps & gap before & gap after & "
        "max $\\|A\\hat x-b\\|$ & min $\\lambda_F(\\hat x)$", rows))
    neg = [(d['n'], d['r'], d['j'], d['rounding']['gap_after']) for d in recs
           if d['rounding'] and d['rounding']['gap_after'] < -1e-6]
    inv = [(d['n'], d['r'], d['j']) for d in recs if d['rounding'] and not d['rounding']['valid']]
    P(f"instances with q(xhat)-v_LR < -1e-6 (diagnostic only; v_LR is not a dual bound): {neg}")
    P(f"instances where the rounding feasibility/monotonicity check fails: {inv}")

    # ---------------- cardinality
    P(); P("== Paragraph 'Cardinality condition' (delta=1e-6)")
    C = [(d, d['card']) for d in recs if d['card']]
    P(f"violations of rho_F <= bound: {sum(c['violated'] for _, c in C)}/{len(C)}")
    hold = [(d, c) for d, c in C if c['holds']]
    P(f"condition (bound<1) holds in {len(hold)}/{len(C)} instances; of these rank-one: "
      f"{sum(ro(d,'LR') for d, _ in hold)}; settings: " +
      ", ".join(sorted({f"n={d['n']},r={d['r']}" for d, _ in hold})))
    for k in keys:
        Cg = [d['card']['bound'] for d in groups[k] if d['card']]
        P(f"  n={k[0]} r={k[1]}: mean bound {np.mean(Cg):.2f}")

    # ---------------- global
    rows = []
    G = [d for d in recs if d['glob']]
    P(); P("== Paragraph 'Comparison with the global optimum'")
    for d in sorted(G, key=lambda d: (d['r'], d['j'])):
        vq, vl, qx = d['glob']['vqp'], d['LR_v'], d['LR_qx']
        rows.append([d['r'], d['j'], f"${vl:.6f}$", f"${vq:.6f}$", sci(vq - vl, 1), sci(qx - vq, 1)])
    if G:
        P(f"{len(G)} instances; max (v_QP - v_LR) = {max(d['glob']['vqp']-d['LR_v'] for d in G):.2e}; "
          f"min = {min(d['glob']['vqp']-d['LR_v'] for d in G):.2e}; "
          f"max q(x*)-v_QP = {max(d['LR_qx']-d['glob']['vqp'] for d in G):.2e}; "
          f"min = {min(d['LR_qx']-d['glob']['vqp'] for d in G):.2e}")
        P("instances among them with lambda_F<0 (delta=1e-6): " +
          (str([(d['r'], d['j']) for d in G if lam_neg(LRl(d)['lam'])]) or "none"))
    open(os.path.join(tdir, "tab_global.tex"), "w").write(table(
        "Global optimum by face enumeration, $n=10$. The last column is $q(x^\\star)-v_{\\rm QP}$ "
        "for the Lifted-RLT solution.", "tab:global", "rrrrrr",
        "$\\operatorname{rank}(N)$ & $j$ & $v_{\\rm LR}$ & $v_{\\rm QP}$ & $v_{\\rm QP}-v_{\\rm LR}$ & "
        "$q(x^\\star)-v_{\\rm QP}$", rows))

    # ---------------- cost
    P(); P("== Solver time (s), mean per model and n")
    for n_ in sorted({d['n'] for d in recs}):
        P(f"  n={n_}: " + ", ".join(
            f"{nm}={np.mean([d['models'][nm]['time'] for d in recs if d['n']==n_]):.1f}" for nm in MODELS))

    open(os.path.join(a.out, "numbers.txt"), "w").write("\n".join(NUM) + "\n")
    print("\n".join(NUM))
    print(f"\nTables written to {tdir}/ ; numbers in {a.out}/numbers.txt")


# --------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["run", "report", "all"])
    ap.add_argument("--out", default="results")
    ap.add_argument("--ns", default="10,20,50")
    ap.add_argument("--ranks", default="1,5")
    ap.add_argument("--per", type=int, default=50, help="instances per (n, rank)")
    ap.add_argument("--jobs", type=int, default=1)
    ap.add_argument("--global_k", type=int, default=5, help="first k instances per (n,rank) get the global optimum")
    ap.add_argument("--global_maxn", type=int, default=10)
    ap.add_argument("--no-global", action="store_true")
    a = ap.parse_args(argv)
    if a.cmd in ("run", "all"):
        cmd_run(a)
    if a.cmd in ("report", "all"):
        cmd_report(a)


# ---- Notebook users: call main(NOTEBOOK_ARGS) explicitly in a cell. -----------
NOTEBOOK_ARGS = ["all", "--out", "results", "--jobs", "1"]
#   smoke test:  ["all", "--out", "test", "--per", "2", "--ns", "10"]
#   faster:      ["all", "--out", "results", "--jobs", "4"]
if __name__ == "__main__":
    # ``%run`` / notebook execution inherits the kernel's private argv
    # (including kernel-<id>.json).  Do not pass those arguments to argparse.
    # Use NOTEBOOK_ARGS in that environment; ordinary command-line execution
    # continues to parse the user's actual command-line arguments.
    if "ipykernel" in sys.modules:
        main(NOTEBOOK_ARGS)
    else:
        main()
