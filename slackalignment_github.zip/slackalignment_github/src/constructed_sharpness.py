
# ================================================================
# CONTROLLED NUMERICAL VALIDATION FOR SLACK-EXACTNESS MANUSCRIPT
#
# Lifted-RLT instances with:
#   - nonzero optimal slack
#   - negative restricted curvature
#   - known exact QP and SDP-RLT optimal values
#   - several dimensions and curvature magnitudes
#
# Outputs:
#   constructed_instances.csv
#   rank_tolerance_sensitivity.csv
#   solver_diagnostics.csv
# ================================================================

import sys
import warnings
import numpy as np
import pandas as pd
import cvxpy as cp

from scipy.linalg import null_space

warnings.filterwarnings("ignore")

print("Python:", sys.version)
print("NumPy:", np.__version__)
print("CVXPY:", cp.__version__)
print("Installed solvers:", cp.installed_solvers())

if "SCS" not in cp.installed_solvers():
    raise RuntimeError("SCS is required. Install it with: pip install scs")


# ------------------------------------------------
# 1. Numerical settings
# ------------------------------------------------

SCS_EPS = 1e-7
SCS_MAX_ITERS = 300000

FRACTIONAL_TOL = 1e-6

RANK_TOLS = [
    1e-4,
    1e-5,
    1e-6,
    1e-7,
    1e-8
]

# Number of equality-constrained pairs.
# Dimension n = 2*k, number of equalities m = k.
DIMENSIONS = [1, 2, 5, 10, 20]

# Negative curvature magnitudes.
ALPHAS = [0.25, 1.0, 2.0]

# A few repetitions are useful for checking numerical stability.
REPETITIONS = 2


# ------------------------------------------------
# 2. Constructed instance
# ------------------------------------------------

def construct_instance(k, alpha):
    """
    Construct a QP with n=2k variables and k pairwise equalities:

        x_(2j) + x_(2j+1) = 1.

    Objective:
        q(x) = -alpha * ||x||^2.

    Thus:
        H = -alpha I,
        c = 0.

    The QP optimal value is exactly:
        v_QP = -alpha*k.

    The Lifted-RLT optimal value is also exactly:
        v_LR = -alpha*k.

    At the central fractional point x_i=1/2, the optimal
    lifted matrix has nonzero slack and negative restricted
    curvature. The gap bound is attained with equality.
    """

    n = 2 * k
    m = k

    A = np.zeros((m, n))

    for j in range(k):
        A[j, 2*j] = 1.0
        A[j, 2*j + 1] = 1.0

    b = np.ones(m)

    H = -alpha * np.eye(n)
    c = np.zeros(n)

    return A, b, H, c


# ------------------------------------------------
# 3. Solve Lifted-RLT using SCS
# ------------------------------------------------

def solve_lifted_rlt(A, b, H, c):

    m, n = A.shape

    x = cp.Variable(n)
    X = cp.Variable((n, n), symmetric=True)

    constraints = []

    # Original constraints
    constraints += [
        A @ x == b,
        x >= 0,
        x <= 1
    ]

    # Lifted equality
    constraints += [
        A @ X == cp.reshape(b, (m, 1), order="F")
                    @ cp.reshape(x, (1, n), order="F")
    ]

    # Shor PSD constraint
    shor = cp.bmat([
        [np.ones((1, 1)), cp.reshape(x, (1, n), order="F")],
        [cp.reshape(x, (n, 1), order="F"), X]
    ])

    constraints += [shor >> 0]

    # Box RLT inequalities
    x_col = cp.reshape(x, (n, 1), order="F")
    x_row = cp.reshape(x, (1, n), order="F")

    constraints += [
        X >= 0,
        X <= x_col,
        X <= x_row,
        X >= x_col + x_row - 1
    ]

    objective = cp.Minimize(
        cp.sum(cp.multiply(H, X)) + c @ x
    )

    problem = cp.Problem(objective, constraints)

    problem.solve(
        solver=cp.SCS,
        eps=SCS_EPS,
        max_iters=SCS_MAX_ITERS,
        normalize=True,
        verbose=False
    )

    if x.value is None or X.value is None:
        raise RuntimeError(
            f"SCS returned no primal solution: {problem.status}"
        )

    xv = np.asarray(x.value).reshape(-1)
    Xv = np.asarray(X.value)
    Xv = 0.5 * (Xv + Xv.T)

    return problem, xv, Xv, constraints


# ------------------------------------------------
# 4. Independent numerical diagnostics
# ------------------------------------------------

def matrix_min_eigenvalue(M):
    M = 0.5 * (M + M.T)
    if M.size == 0:
        return np.inf
    return float(np.linalg.eigvalsh(M)[0])


def normalized_slack_residual(X, x):
    S = X - np.outer(x, x)
    return (
        np.linalg.norm(S, "fro")
        / max(1.0, np.linalg.norm(X, "fro"))
    )


def fractional_indices(x, tol=FRACTIONAL_TOL):
    return np.where(
        (x > tol) & (x < 1.0 - tol)
    )[0]


def restricted_hessian_eigenvalue(H, A, F):

    if len(F) == 0:
        return np.inf, 0, 0

    AF = A[:, F]
    Z = null_space(AF)

    dimension = Z.shape[1]

    if dimension == 0:
        return np.inf, 0, 0

    HFF = H[np.ix_(F, F)]
    Hred = Z.T @ HFF @ Z
    Hred = 0.5 * (Hred + Hred.T)

    return (
        float(np.linalg.eigvalsh(Hred)[0]),
        dimension,
        np.linalg.matrix_rank(AF)
    )


def primal_residuals(A, b, H, c, x, X):

    n = len(x)

    S = X - np.outer(x, x)
    S = 0.5 * (S + S.T)

    equality = np.linalg.norm(A @ x - b, np.inf)

    lifted_equality = np.linalg.norm(
        A @ X - np.outer(b, x), np.inf
    )

    box = max(
        float(np.max(np.maximum(-x, 0))),
        float(np.max(np.maximum(x - 1, 0)))
    )

    rlt_violations = [
        np.max(np.maximum(-X, 0)),
        np.max(np.maximum(X - x[:, None], 0)),
        np.max(np.maximum(X - x[None, :], 0)),
        np.max(np.maximum(
            x[:, None] + x[None, :] - 1 - X, 0
        ))
    ]

    rlt = float(max(rlt_violations))

    shor = np.block([
        [np.ones((1, 1)), x[None, :]],
        [x[:, None], X]
    ])

    psd_min_eig = matrix_min_eigenvalue(shor)

    slack_min_eig = matrix_min_eigenvalue(S)

    return {
        "equality_residual": equality,
        "lifted_equality_residual": lifted_equality,
        "box_violation": box,
        "rlt_violation": rlt,
        "shor_min_eigenvalue": psd_min_eig,
        "slack_min_eigenvalue": slack_min_eig,
        "max_primal_residual": max(
            equality,
            lifted_equality,
            box,
            rlt,
            max(0.0, -psd_min_eig),
            max(0.0, -slack_min_eig)
        )
    }


# ------------------------------------------------
# 5. Extract SCS diagnostics
# ------------------------------------------------

def extract_scs_info(problem):

    result = {
        "solver_status": str(problem.status),
        "solver_name": str(problem.solver_stats.solver_name),
        "solve_time": problem.solver_stats.solve_time,
        "num_iters": problem.solver_stats.num_iters,
        "scs_primal_objective": np.nan,
        "scs_dual_objective": np.nan,
        "scs_gap": np.nan,
        "scs_primal_residual": np.nan,
        "scs_dual_residual": np.nan
    }

    extra = problem.solver_stats.extra_stats

    if isinstance(extra, dict):
        info = extra.get("info", {})

        if isinstance(info, dict):
            result["scs_primal_objective"] = info.get("pobj", np.nan)
            result["scs_dual_objective"] = info.get("dobj", np.nan)
            result["scs_gap"] = info.get("gap", np.nan)
            result["scs_primal_residual"] = info.get("res_pri", np.nan)
            result["scs_dual_residual"] = info.get("res_dual", np.nan)

    return result


# ------------------------------------------------
# 6. Run the constructed experiment
# ------------------------------------------------

main_rows = []
sensitivity_rows = []
solver_rows = []

instance_number = 0

for k in DIMENSIONS:

    for alpha in ALPHAS:

        for rep in range(REPETITIONS):

            instance_number += 1

            A, b, H, c = construct_instance(k, alpha)

            n = len(c)

            print(
                f"\nInstance {instance_number}: "
                f"n={n}, m={k}, alpha={alpha}, rep={rep+1}"
            )

            problem, x, X, constraints = solve_lifted_rlt(
                A, b, H, c
            )

            S = X - np.outer(x, x)
            S = 0.5 * (S + S.T)

            F = fractional_indices(x)

            lambda_F, nullity_F, rank_AF = (
                restricted_hessian_eigenvalue(H, A, F)
            )

            qx = float(x @ H @ x + c @ x)
            v_primal = float(problem.value)

            # Exact theoretical values for this construction
            v_QP_exact = -alpha * k
            v_LR_exact = -alpha * k

            # Theoretical gap-bound components
            trace_S = float(np.trace(S))

            coordinate_bound = float(
                np.sum(x[F] * (1.0 - x[F]))
            )

            cardinality_bound = len(F) / 4.0

            curvature = max(0.0, -lambda_F)

            trace_bound = curvature * trace_S
            coordinate_trace_bound = curvature * coordinate_bound
            cardinality_bound_value = curvature * cardinality_bound

            # Numerical gaps
            measured_gap = qx - v_primal
            exact_gap = qx - v_LR_exact

            # SCS dual objective is a numerical dual diagnostic.
            # It is NOT treated as a formal certificate.
            scs = extract_scs_info(problem)

            dual_value = scs["scs_dual_objective"]

            if np.isfinite(dual_value):
                conservative_dual_gap = qx - dual_value
                dual_bound_check = (
                    conservative_dual_gap
                    <= trace_bound + 5e-5
                )
            else:
                conservative_dual_gap = np.nan
                dual_bound_check = False

            residuals = primal_residuals(
                A, b, H, c, x, X
            )

            rank_resid = normalized_slack_residual(X, x)

            # Support leakage outside F x F
            outside = np.ones((n, n), dtype=bool)
            outside[np.ix_(F, F)] = False

            leakage = (
                float(np.max(np.abs(S[outside])))
                if np.any(outside)
                else 0.0
            )

            # Numerical rank of slack
            slack_eigs = np.linalg.eigvalsh(S)
            slack_rank = int(
                np.sum(slack_eigs > 1e-6)
            )

            rank_bound = max(0, len(F) - rank_AF)

            main_row = {
                "instance": instance_number,
                "n": n,
                "m": k,
                "alpha": alpha,
                "rep": rep + 1,

                "status": problem.status,

                "fractional_count": len(F),
                "rank_A_F": rank_AF,
                "nullity_A_F": nullity_F,

                "lambda_F": lambda_F,
                "trace_S": trace_S,
                "slack_rank": slack_rank,
                "rank_bound": rank_bound,

                "qx": qx,
                "v_LR_solver": v_primal,
                "v_LR_exact": v_LR_exact,
                "v_QP_exact": v_QP_exact,

                "measured_gap": measured_gap,
                "exact_gap": exact_gap,

                "trace_bound": trace_bound,
                "coordinate_trace_bound": coordinate_trace_bound,
                "cardinality_bound": cardinality_bound_value,

                "support_leakage": leakage,
                "rank_residual": rank_resid,

                "dual_objective": dual_value,
                "conservative_dual_gap": conservative_dual_gap,
                "dual_bound_check": dual_bound_check,

                **residuals
            }

            main_rows.append(main_row)

            solver_rows.append({
                "instance": instance_number,
                "n": n,
                "alpha": alpha,
                **scs,
                **residuals
            })

            # Rank tolerance sensitivity
            for tol in RANK_TOLS:

                is_rank_one = rank_resid < tol

                sensitivity_rows.append({
                    "instance": instance_number,
                    "n": n,
                    "alpha": alpha,
                    "rank_tolerance": tol,
                    "rank_residual": rank_resid,
                    "classified_rank_one": is_rank_one
                })

            print(
                "  status:", problem.status,
                "| fractional:", len(F),
                "| lambda_F:", round(lambda_F, 8),
                "| rank residual:", f"{rank_resid:.3e}",
                "| gap:", f"{measured_gap:.6e}",
                "| bound:", f"{trace_bound:.6e}"
            )


# ------------------------------------------------
# 7. Save detailed outputs
# ------------------------------------------------

main_df = pd.DataFrame(main_rows)
sensitivity_df = pd.DataFrame(sensitivity_rows)
solver_df = pd.DataFrame(solver_rows)

main_df.to_csv(
    "constructed_instances.csv",
    index=False
)

sensitivity_df.to_csv(
    "rank_tolerance_sensitivity.csv",
    index=False
)

solver_df.to_csv(
    "solver_diagnostics.csv",
    index=False
)


# ------------------------------------------------
# 8. Summary and automatic checks
# ------------------------------------------------

print("\n" + "="*72)
print("CONSTRUCTED-INSTANCE SUMMARY")
print("="*72)

summary = main_df.groupby(
    ["n", "alpha"]
).agg(
    instances=("instance", "count"),
    mean_fractional=("fractional_count", "mean"),
    mean_lambda_F=("lambda_F", "mean"),
    mean_trace_S=("trace_S", "mean"),
    mean_gap=("measured_gap", "mean"),
    mean_trace_bound=("trace_bound", "mean"),
    max_primal_residual=("max_primal_residual", "max"),
    max_support_leakage=("support_leakage", "max"),
    max_rank_residual=("rank_residual", "max")
).reset_index()

print(summary.to_string(index=False))

print("\n" + "="*72)
print("RANK-TOLERANCE SENSITIVITY")
print("="*72)

rank_summary = sensitivity_df.groupby(
    "rank_tolerance"
).agg(
    rank_one_count=("classified_rank_one", "sum"),
    total=("instance", "count")
).reset_index()

rank_summary["rank_one_fraction"] = (
    rank_summary["rank_one_count"] /
    rank_summary["total"]
)

print(rank_summary.to_string(index=False))


# ------------------------------------------------
# 9. Mathematical consistency checks
# ------------------------------------------------

print("\n" + "="*72)
print("AUTOMATIC CONSISTENCY CHECKS")
print("="*72)

# All instances should have negative restricted curvature
negative_curvature_count = int(
    (main_df["lambda_F"] < -1e-5).sum()
)

# Nonzero slack
nonzero_slack_count = int(
    (main_df["trace_S"] > 1e-5).sum()
)

# Gap bound, using solver primal objective
gap_bound_pass = int(
    (
        main_df["measured_gap"]
        <= main_df["trace_bound"] + 5e-5
    ).sum()
)

# Rank bound
rank_bound_pass = int(
    (
        main_df["slack_rank"]
        <= main_df["rank_bound"]
    ).sum()
)

# Exact theoretical gap bound for this family
exact_bound_error = np.max(
    np.abs(
        main_df["exact_gap"] -
        main_df["trace_bound"]
    )
)

# Primal feasibility
feasibility_pass = int(
    (main_df["max_primal_residual"] <= 5e-5).sum()
)

print(
    "Negative restricted curvature:",
    negative_curvature_count, "/", len(main_df)
)

print(
    "Nonzero optimal slack:",
    nonzero_slack_count, "/", len(main_df)
)

print(
    "Numerical gap-bound checks passed:",
    gap_bound_pass, "/", len(main_df)
)

print(
    "Slack-rank checks passed:",
    rank_bound_pass, "/", len(main_df)
)

print(
    "Primal feasibility checks passed:",
    feasibility_pass, "/", len(main_df)
)

print(
    "Maximum exact-gap identity error:",
    f"{exact_bound_error:.3e}"
)

print(
    "Conservative dual-bound checks passed:",
    int(main_df["dual_bound_check"].sum()),
    "/", len(main_df)
)

print("\nFiles saved:")
print("  constructed_instances.csv")
print("  rank_tolerance_sensitivity.csv")
print("  solver_diagnostics.csv")

print("\nIMPORTANT:")
print(
    "SCS dual objectives and residuals are numerical diagnostics, "
    "not independently verified formal certificates."
)
