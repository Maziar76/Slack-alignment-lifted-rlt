
# ================================================================
# COUPLED NUMERICAL EXPERIMENT FOR SLACK-EXACTNESS MANUSCRIPT
#
# Tests:
#   1. Non-diagonal reduced Hessians
#   2. Coupled fractional variables
#   3. Nonzero SDP slack
#   4. Negative restricted curvature
#   5. Exact QP values by exhaustive sign enumeration
#   6. Lifted-RLT gap bound
#   7. Rank-one tolerance sensitivity
#   8. SCS primal/dual diagnostics
#
# Dimensions: n = 10, 20, 40
# Equality constraints: m = n/2
#
# Outputs:
#   coupled_instances.csv
#   coupled_rank_sensitivity.csv
#   coupled_solver_diagnostics.csv
# ================================================================

import sys
import warnings
import numpy as np
import pandas as pd
import cvxpy as cp

from scipy.linalg import null_space

warnings.filterwarnings("ignore")

print("Python:", sys.version)
print("NumPy:", np.__version__)
print("CVXPY:", cp.__version__)
print("Installed solvers:", cp.installed_solvers())

if "SCS" not in cp.installed_solvers():
    raise RuntimeError("Please install SCS: pip install scs")


# ------------------------------------------------
# 1. Experiment settings
# ------------------------------------------------

SCS_EPS = 1e-7
SCS_MAX_ITERS = 300000

FRACTIONAL_TOL = 1e-6

RANK_TOLS = [
    1e-4, 1e-5, 1e-6, 1e-7, 1e-8
]

K_VALUES = [5, 10, 20]

REPETITIONS = 3

# Dense perturbation added to the odd-cycle interaction matrix.
PERTURBATION = 0.025

BASE_SEED = 20261124


# ------------------------------------------------
# 2. Pairwise equality structure
# ------------------------------------------------

def equality_structure(k):

    n = 2 * k

    A = np.zeros((k, n))

    for j in range(k):
        A[j, 2*j] = 1.0
        A[j, 2*j+1] = 1.0

    b = np.ones(k)

    # Orthonormal basis of ker(A)
    D = np.zeros((n, k))

    for j in range(k):
        D[2*j, j] = 1.0 / np.sqrt(2.0)
        D[2*j+1, j] = -1.0 / np.sqrt(2.0)

    return A, b, D


# ------------------------------------------------
# 3. Construct coupled reduced Hessian
# ------------------------------------------------

def construct_coupled_matrix(k, seed):

    rng = np.random.default_rng(seed)

    # Use disjoint odd cycles of length 5.
    # Each block has a nonzero Max-Cut SDP integrality gap.

    W = np.zeros((k, k))

    for start in range(0, k, 5):

        for j in range(5):
            a = start + j
            b = start + (j + 1) % 5

            W[a, b] = -1.0
            W[b, a] = -1.0

    # Add a small dense symmetric perturbation.
    R = rng.normal(size=(k, k))
    R = 0.5 * (R + R.T)
    np.fill_diagonal(R, 0.0)

    W += PERTURBATION * R

    # Shift W to make C positive definite.
    eig_min = np.linalg.eigvalsh(W)[0]

    shift = max(0.0, -eig_min) + 0.25

    C = W + shift * np.eye(k)
    C = 0.5 * (C + C.T)

    return C, W, shift


def construct_instance(k, seed):

    A, b, D = equality_structure(k)

    C, W, shift = construct_coupled_matrix(k, seed)

    # Restricted Hessian:
    # D' H D = -C
    H = -D @ C @ D.T
    H = 0.5 * (H + H.T)

    c = np.zeros(2*k)

    return A, b, H, c, D, C, W, shift


# ------------------------------------------------
# 4. Exact QP value by sign enumeration
# ------------------------------------------------

def exact_qp_value(C, chunk_size=65536):

    k = C.shape[0]

    total = 2**k

    best_score = -np.inf
    best_sign = None

    powers = np.arange(k, dtype=np.uint64)

    for start in range(0, total, chunk_size):

        stop = min(start + chunk_size, total)

        indices = np.arange(
            start, stop, dtype=np.uint64
        )[:, None]

        bits = (indices >> powers[None, :]) & 1

        signs = 1.0 - 2.0 * bits.astype(float)

        scores = np.einsum(
            "bi,ij,bj->b",
            signs, C, signs,
            optimize=True
        )

        local_index = int(np.argmax(scores))

        if scores[local_index] > best_score:

            best_score = float(scores[local_index])
            best_sign = signs[local_index].copy()

    # t = sign/sqrt(2)
    # q(x) = -t'C t
    v_qp = -0.5 * best_score

    return v_qp, best_score, best_sign


# ------------------------------------------------
# 5. Solve Lifted-RLT
# ------------------------------------------------

def solve_lifted_rlt(A, b, H, c):

    m, n = A.shape

    x = cp.Variable(n)
    X = cp.Variable((n, n), symmetric=True)

    constraints = [
        A @ x == b,
        x >= 0,
        x <= 1
    ]

    # Lifted equality
    constraints += [
        A @ X == cp.reshape(
            b, (m, 1), order="F"
        ) @ cp.reshape(
            x, (1, n), order="F"
        )
    ]

    # Shor PSD constraint
    shor = cp.bmat([
        [np.ones((1, 1)), cp.reshape(x, (1, n), order="F")],
        [cp.reshape(x, (n, 1), order="F"), X]
    ])

    constraints += [shor >> 0]

    x_col = cp.reshape(x, (n, 1), order="F")
    x_row = cp.reshape(x, (1, n), order="F")

    # Box RLT inequalities
    constraints += [
        X >= 0,
        X <= x_col,
        X <= x_row,
        X >= x_col + x_row - 1
    ]

    objective = cp.Minimize(
        cp.sum(cp.multiply(H, X)) + c @ x
    )

    problem = cp.Problem(objective, constraints)

    problem.solve(
        solver=cp.SCS,
        eps=SCS_EPS,
        max_iters=SCS_MAX_ITERS,
        normalize=True,
        verbose=False
    )

    if x.value is None or X.value is None:
        raise RuntimeError(
            f"No primal solution: {problem.status}"
        )

    xv = np.asarray(x.value).reshape(-1)

    Xv = np.asarray(X.value)
    Xv = 0.5 * (Xv + Xv.T)

    return problem, xv, Xv


# ------------------------------------------------
# 6. Restricted curvature and residuals
# ------------------------------------------------

def get_fractional_indices(x):

    return np.where(
        (x > FRACTIONAL_TOL) &
        (x < 1.0 - FRACTIONAL_TOL)
    )[0]


def restricted_curvature(H, A, F):

    if len(F) == 0:
        return np.inf, 0, 0

    AF = A[:, F]

    Z = null_space(AF)

    nullity = Z.shape[1]

    if nullity == 0:
        return np.inf, 0, np.linalg.matrix_rank(AF)

    HFF = H[np.ix_(F, F)]

    Hred = Z.T @ HFF @ Z
    Hred = 0.5 * (Hred + Hred.T)

    eigs = np.linalg.eigvalsh(Hred)

    return (
        float(eigs[0]),
        nullity,
        np.linalg.matrix_rank(AF)
    )


def min_eigenvalue(M):

    M = 0.5 * (M + M.T)

    if M.size == 0:
        return np.inf

    return float(np.linalg.eigvalsh(M)[0])


def normalized_slack_residual(X, x):

    S = X - np.outer(x, x)

    return (
        np.linalg.norm(S, "fro") /
        max(1.0, np.linalg.norm(X, "fro"))
    )


def calculate_residuals(A, b, x, X):

    n = len(x)

    S = X - np.outer(x, x)
    S = 0.5 * (S + S.T)

    equality = np.linalg.norm(A @ x - b, np.inf)

    lifted_equality = np.linalg.norm(
        A @ X - np.outer(b, x), np.inf
    )

    box = max(
        float(np.max(np.maximum(-x, 0))),
        float(np.max(np.maximum(x - 1, 0)))
    )

    rlt = max(
        float(np.max(np.maximum(-X, 0))),
        float(np.max(np.maximum(X - x[:, None], 0))),
        float(np.max(np.maximum(X - x[None, :], 0))),
        float(np.max(np.maximum(
            x[:, None] + x[None, :] - 1 - X, 0
        )))
    )

    shor = np.block([
        [np.ones((1, 1)), x[None, :]],
        [x[:, None], X]
    ])

    shor_min = min_eigenvalue(shor)
    slack_min = min_eigenvalue(S)

    return {
        "equality_residual": equality,
        "lifted_equality_residual": lifted_equality,
        "box_violation": box,
        "rlt_violation": rlt,
        "shor_min_eigenvalue": shor_min,
        "slack_min_eigenvalue": slack_min,
        "max_primal_residual": max(
            equality,
            lifted_equality,
            box,
            rlt,
            max(0.0, -shor_min),
            max(0.0, -slack_min)
        )
    }


# ------------------------------------------------
# 7. Solver diagnostics
# ------------------------------------------------

def solver_diagnostics(problem):

    info = {}

    info["solver_status"] = str(problem.status)
    info["solver_name"] = str(problem.solver_stats.solver_name)
    info["solve_time"] = problem.solver_stats.solve_time
    info["iterations"] = problem.solver_stats.num_iters

    for key in [
        "pobj", "dobj", "gap",
        "res_pri", "res_dual"
    ]:
        info[key] = np.nan

    extra = problem.solver_stats.extra_stats

    if isinstance(extra, dict):

        scs_info = extra.get("info", {})

        if isinstance(scs_info, dict):

            info["pobj"] = scs_info.get("pobj", np.nan)
            info["dobj"] = scs_info.get("dobj", np.nan)
            info["gap"] = scs_info.get("gap", np.nan)
            info["res_pri"] = scs_info.get("res_pri", np.nan)
            info["res_dual"] = scs_info.get("res_dual", np.nan)

    return info


# ------------------------------------------------
# 8. Run experiments
# ------------------------------------------------

main_rows = []
sensitivity_rows = []
solver_rows = []

instance_id = 0

for k in K_VALUES:

    for rep in range(REPETITIONS):

        instance_id += 1

        seed = BASE_SEED + 1000*k + rep

        print("\n" + "="*65)
        print(
            f"Instance {instance_id}: "
            f"k={k}, n={2*k}, repetition={rep+1}"
        )
        print("="*65)

        A, b, H, c, D, C, W, shift = construct_instance(
            k, seed
        )

        # Verify non-diagonal reduced Hessian
        offdiag_norm = np.linalg.norm(
            C - np.diag(np.diag(C)), "fro"
        )

        matrix_norm = np.linalg.norm(C, "fro")

        coupling_ratio = offdiag_norm / matrix_norm

        # Exact QP solution by enumeration
        v_qp, max_sign_score, best_sign = exact_qp_value(C)

        # Solve Lifted-RLT
        problem, x, X = solve_lifted_rlt(A, b, H, c)

        if problem.status not in ["optimal", "optimal_inaccurate"]:
            print("WARNING: solver status =", problem.status)

        S = X - np.outer(x, x)
        S = 0.5 * (S + S.T)

        F = get_fractional_indices(x)

        lambda_F, nullity_F, rank_AF = restricted_curvature(
            H, A, F
        )

        qx = float(x @ H @ x)

        v_lr = float(problem.value)

        # Actual QP-LR integrality gap
        actual_gap = v_qp - v_lr

        # A posteriori gap quantity
        a_posteriori_gap = qx - v_lr

        trace_S = float(np.trace(S))

        coordinate_sum = float(
            np.sum(x[F] * (1.0 - x[F]))
        )

        cardinality_sum = len(F) / 4.0

        curvature = max(0.0, -lambda_F)

        trace_bound = curvature * trace_S

        coordinate_bound = curvature * coordinate_sum

        cardinality_bound = curvature * cardinality_sum

        # Fractional-face support leakage
        n = len(x)

        outside = np.ones((n, n), dtype=bool)
        outside[np.ix_(F, F)] = False

        leakage = (
            float(np.max(np.abs(S[outside])))
            if np.any(outside)
            else 0.0
        )

        # Numerical slack rank
        slack_eigs = np.linalg.eigvalsh(S)

        slack_rank = int(
            np.sum(slack_eigs > 1e-6)
        )

        rank_bound = max(0, len(F) - rank_AF)

        rank_resid = normalized_slack_residual(X, x)

        residuals = calculate_residuals(A, b, x, X)

        diag = solver_diagnostics(problem)

        dual_obj = diag["dobj"]

        if np.isfinite(dual_obj):

            dual_gap_upper = qx - dual_obj

            dual_check = (
                dual_gap_upper <= trace_bound + 1e-4
            )

        else:

            dual_gap_upper = np.nan
            dual_check = False

        # ------------------------------------------------
        # Main record
        # ------------------------------------------------

        row = {
            "instance": instance_id,
            "seed": seed,
            "k": k,
            "n": n,
            "m": k,
            "repetition": rep + 1,

            "status": problem.status,

            "C_min_eigenvalue": np.linalg.eigvalsh(C)[0],
            "C_max_eigenvalue": np.linalg.eigvalsh(C)[-1],
            "C_coupling_ratio": coupling_ratio,
            "diagonal_shift": shift,

            "fractional_count": len(F),
            "rank_A_F": rank_AF,
            "nullity_A_F": nullity_F,

            "lambda_F": lambda_F,

            "trace_S": trace_S,
            "slack_rank": slack_rank,
            "slack_rank_bound": rank_bound,

            "v_QP_exact": v_qp,
            "v_LR_solver": v_lr,

            "actual_QP_LR_gap": actual_gap,
            "qx": qx,
            "a_posteriori_gap": a_posteriori_gap,

            "trace_bound": trace_bound,
            "coordinate_bound": coordinate_bound,
            "cardinality_bound": cardinality_bound,

            "rank_residual": rank_resid,
            "support_leakage": leakage,

            "dual_objective": dual_obj,
            "dual_gap_upper": dual_gap_upper,
            "dual_bound_check": dual_check,

            **residuals
        }

        main_rows.append(row)

        solver_rows.append({
            "instance": instance_id,
            "n": n,
            "k": k,
            **diag,
            **residuals
        })

        # ------------------------------------------------
        # Rank tolerance sensitivity
        # ------------------------------------------------

        for tol in RANK_TOLS:

            sensitivity_rows.append({
                "instance": instance_id,
                "n": n,
                "k": k,
                "rank_tolerance": tol,
                "rank_residual": rank_resid,
                "classified_rank_one": rank_resid < tol
            })

        print("Status:", problem.status)
        print("Coupling ratio:", f"{coupling_ratio:.4f}")
        print("Fractional coordinates:", len(F))
        print("Restricted minimum eigenvalue:", lambda_F)
        print("Exact QP value:", v_qp)
        print("Lifted-RLT value:", v_lr)
        print("Actual QP-LR gap:", actual_gap)
        print("A posteriori gap:", a_posteriori_gap)
        print("Trace bound:", trace_bound)
        print("Slack residual:", f"{rank_resid:.5e}")
        print("Primal residual:", residuals["max_primal_residual"])
        print("Dual bound check:", dual_check)


# ------------------------------------------------
# 9. Save outputs
# ------------------------------------------------

main_df = pd.DataFrame(main_rows)
sensitivity_df = pd.DataFrame(sensitivity_rows)
solver_df = pd.DataFrame(solver_rows)

main_df.to_csv("coupled_instances.csv", index=False)

sensitivity_df.to_csv(
    "coupled_rank_sensitivity.csv",
    index=False
)

solver_df.to_csv(
    "coupled_solver_diagnostics.csv",
    index=False
)


# ------------------------------------------------
# 10. Summary
# ------------------------------------------------

print("\n" + "="*75)
print("COUPLED-INSTANCE SUMMARY")
print("="*75)

summary = main_df.groupby("n").agg(
    instances=("instance", "count"),
    mean_coupling=("C_coupling_ratio", "mean"),
    mean_fractional=("fractional_count", "mean"),
    mean_lambda_F=("lambda_F", "mean"),
    mean_slack=("trace_S", "mean"),
    mean_actual_gap=("actual_QP_LR_gap", "mean"),
    mean_aposteriori_gap=("a_posteriori_gap", "mean"),
    mean_trace_bound=("trace_bound", "mean"),
    max_primal_residual=("max_primal_residual", "max"),
    max_rank_residual=("rank_residual", "max")
).reset_index()

print(summary.to_string(index=False))


# ------------------------------------------------
# 11. Rank tolerance summary
# ------------------------------------------------

print("\n" + "="*75)
print("RANK TOLERANCE SENSITIVITY")
print("="*75)

rank_summary = sensitivity_df.groupby(
    "rank_tolerance"
).agg(
    rank_one_count=("classified_rank_one", "sum"),
    total=("instance", "count")
).reset_index()

rank_summary["rank_one_fraction"] = (
    rank_summary["rank_one_count"] /
    rank_summary["total"]
)

print(rank_summary.to_string(index=False))


# ------------------------------------------------
# 12. Mathematical checks
# ------------------------------------------------

print("\n" + "="*75)
print("MATHEMATICAL CONSISTENCY CHECKS")
print("="*75)

total = len(main_df)

print(
    "Negative restricted curvature:",
    int((main_df["lambda_F"] < -1e-5).sum()),
    "/", total
)

print(
    "Nonzero slack:",
    int((main_df["trace_S"] > 1e-5).sum()),
    "/", total
)

print(
    "Positive actual QP-LR gap:",
    int((main_df["actual_QP_LR_gap"] > 1e-5).sum()),
    "/", total
)

print(
    "A posteriori gap-bound checks:",
    int((
        main_df["a_posteriori_gap"]
        <= main_df["trace_bound"] + 1e-4
    ).sum()),
    "/", total
)

print(
    "Slack-rank checks:",
    int((
        main_df["slack_rank"]
        <= main_df["slack_rank_bound"]
    ).sum()),
    "/", total
)

print(
    "Primal feasibility checks:",
    int((
        main_df["max_primal_residual"] <= 1e-4
    ).sum()),
    "/", total
)

print(
    "Dual diagnostic checks:",
    int(main_df["dual_bound_check"].sum()),
    "/", total
)

print("\nSaved files:")
print("  coupled_instances.csv")
print("  coupled_rank_sensitivity.csv")
print("  coupled_solver_diagnostics.csv")

print("\nIMPORTANT:")
print(
    "SCS dual objectives are numerical diagnostics, not "
    "independently verified formal dual certificates."
)
